BETA RELEASE 3rd August, 2019
=============================

The beta has a few limitations:

-Sky Skipper doesn't work
-Popeye original ROM set will reset at the beggining of a game. The problem is that the protection chip is not well implemented
-Use ROMs popeyeu and popeyef from MAME ROM set
-There is a region on the left side of the screen that is a mirror of the right hand side. It shouldn't be there
-The letter "K" of "King Features Syndicate" is not shown
-There is a 1-line misalignment between sprites and background
-Avatar for patrons are not shown, only names.

MiST
====
The VGA output may not work on some screens. 15kHz output works and is the recommended setting

MiSTer
======
HDMI output looks squeezed.
Sprites look blurry when moving (HDMI only). This is due to a limitation of interlaced signal processing on MiSTer and it may be the same in the final version. 
OSD display has horizontal red lines
VGA connector only outputs 15kHz signal, which is the recommended setting.